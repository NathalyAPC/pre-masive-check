/**
 * CSV de ejemplo que se muestra al abrir la página.
 * Es una copia de ejemplos/ejemplo.csv (está aquí para que funcione también
 * abriendo index.html con doble clic, sin servidor). Si cambias uno, cambia el otro;
 * la prueba "el ejemplo de la página coincide con ejemplos/ejemplo.csv" lo verifica.
 */
window.SAMPLE_CSV = [
  'external_id,name,price,brand,description,main_image,category_id,stock,variant_sku,weight_kg,width_cm,height_cm,length_cm',
  'EJ-0001,Audífonos Inalámbricos Bluetooth 5.0 Negro,45,Genérica,Audífonos,https://ejemplo.com/img/1.webp,101,3,,0.3,22,20,10',
  'EJ-0002,Audífonos Headset Con Micrófono Para Pc Usb,45,Genérica,Audífonos,,101,10,,3,42,30,8',
  'EJ-0003,Toner Compatible Samsung 116 Negro Negro,37.18,,Tóner,https://ejemplo.com/img/3.webp,205,2,,1.4,40,22,14',
  'EJ-0004,Mouse Clásico Usb Negro,7,,Mouse,,,11,,0.2,15,10,5',
  'EJ-0005,Cartucho Tinta Hp 712 Negro 38 Ml,75,HP,Cartucho,https://ejemplo.com/img/5.webp,205,20,,0.3,12,10,4',
  'EJ-0006,Cartucho Tinta HP 712 Negro 38 ML,$72.50,HP,Cartucho,https://ejemplo.com/img/5.webp,205,6,,0.3,12,10,4',
  'EJ-0007,Tóner Compatible Hp Cf400a,60,HP,Tóner,https://ejemplo.com/img/7.webp,205,4,EJ-0007-A,1.2,35,20,12',
  'EJ-0007,Tóner Compatible Hp Cf400a,60,,,,,0,EJ-0007-B,,,,',
  'EJ-0007,Tóner Compatible Hp Cf400a,60,,,,,2.5,EJ-0007-B,,,,',
  'EJ-0008,"Kit Tinta Epson 544 De 140 Ml 4 Colores Compatible Kit",90,Epson,Kit de tinta,https://ejemplo.com/img/8.webp,205,9,,0.8,20,,10',
  'EJ-0009,"Caja Registradora, Cheques Y Más",155,Agiler,Caja,www.ejemplo.com/img/9.webp,310,10,,4.5,42,36,0',
  ''
].join('\n');
